﻿internal class sqlDataReader
{
}