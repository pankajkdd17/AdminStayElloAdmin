﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class content_AddIncome : System.Web.UI.Page
{
    EditData ed = new EditData();
    AddUsers uc = new AddUsers();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["s_MobileNo"] != null)
            {
                if (Session["propertyvalue"] != null)
                {
                    if (Session["propertyvalue"].ToString() == "0")
                    {
                        
                        Session["propertyvalue"] = "1";
                    }
                    else
                    {
                    }
                }
                else
                {
                   
                    Session["propertyvalue"] = "1";
                }
                if (Request.QueryString["d_id"] != null)
                {
                    string d_id = Request.QueryString["d_id"].ToString();
                    LoadDues(d_id);

                }
            }
            else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                Response.Redirect("~/content/login.aspx");
            }
        }
        
    }

    private void LoadDues(string d_id)
    {
        SqlDataReader sdr = ed.GetDues(d_id);
        if (sdr.HasRows)
        {
            if (sdr.Read())
            {
                txtDuesAmount.Text = sdr["d_DuesAmount"].ToString();
                txtRemark.Text = sdr["d_Remark"].ToString();
                txtRecivingDate.Text = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            }
        }
        sdr.Close();
    }

    protected void btnReciveDue_Click(object sender, EventArgs e)
    {
        try
        {
            string d_id = Request.QueryString["d_id"].ToString();

            if (txtDuesAmount.Text.Length > 0)
            {
                uc.UpdateDuesRecived(d_id, txtDuesAmount.Text, txtRecivingDate.Text, txtRemark.Text);
                string textmsg = " Dues Recived Successfully";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                txtDuesAmount.Text = string.Empty;
                txtRemark.Text = string.Empty;
                txtRecivingDate.Text = string.Empty;
            }
            else
            {
                string errormsg = "Please Enter Recived Amount";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + errormsg + "')</script>", false);
            }


        }
        catch (Exception Ex)
        {
            string errormsg = Ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + errormsg + "')</script>", false);
        }
    }
    protected void btnViewDues_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Content/Dues.aspx");
    }
}