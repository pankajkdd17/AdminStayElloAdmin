﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class content_AddDues : System.Web.UI.Page
{
    EditData ed = new EditData();
    AddUsers uc = new AddUsers();
    GeneralFunctions.GeneralFunctions Gf = new GeneralFunctions.GeneralFunctions();



    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            if (Session["s_MobileNo"] != null)
            {
                Gf.FillDueType("d_id", "d_name", "tbl_DueType", ddlDuesType, "");
                if (Session["propertyvalue"] != null)
                {
                    string PropertyVale = Session["propertyvalue"].ToString();
                    Gf.FillPayee("t_id", "t_name", "Tenants", ddlPayee, "", PropertyVale);
                    if(Session["propertyvalue"].ToString() == "0")
                    {
                        Session["propertyvalue"] = "1";
                    }
                    else
                    {
                    }
                }
                else
                {
                    Session["propertyvalue"] = "1";
                }

                
                btnDues.Visible = true;
                btnSaveChenges.Visible = false;


                if (Request.QueryString["d_id"] != null)
                {
                    string d_id = Request.QueryString["d_id"].ToString();
                    LoadDues(d_id);
                    btnDues.Visible = false;
                    btnSaveChenges.Visible = true;
                }
            }
            else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                Response.Redirect("~/content/login.aspx");
            }
        }
        
    }

    private void LoadDues(string d_id)
    {

        SqlDataReader sdr = ed.GetDues(d_id);
        if (sdr.HasRows)
        {
            if (sdr.Read())
            {

                ddlPayee.SelectedItem.Text = sdr["d_PayeeText"].ToString();
                ddlPayee.SelectedItem.Value = sdr["d_PayeeValue"].ToString();
                txtRoomNoMobile.Text = sdr["d_RoomNo"].ToString();
                string mobile = sdr["d_t_Mobile"].ToString();
                ddlDuesType.SelectedItem.Text = sdr["d_DuesTypeText"].ToString();
                ddlDuesType.SelectedItem.Value = sdr["d_DuesTypeValue"].ToString();
                txtDuesAmount.Text = sdr["d_DuesAmount"].ToString();
                txtDuesDate.Text = sdr["d_DuesDate"].ToString();
                txtDuesMonth.Text = sdr["d_DuesMonth"].ToString();
                txtRemark.Text = sdr["d_Remark"].ToString();
                btnDues.Visible = false;
                btnSaveChenges.Visible = true;
                ddlPayee.Attributes.Add("disabled", "disabled");
            }
        }
        sdr.Close();
    }


    protected void btnDues_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlPayee.SelectedItem.Value != "0")
            {
                DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
                string PropertyName = ddlPropertyName.SelectedItem.Text;
                string PropertyVale = ddlPropertyName.SelectedValue;
                if (PropertyVale != "0")
                {
                    string t_Mobile = Session["t_MobileNo"].ToString();
                    string mobile = Session["s_MobileNo"].ToString();
                    txtRoomNoMobile.Text = Session["t_RoomNo"].ToString();
                    uc.AddDues(mobile, PropertyName, PropertyVale, ddlPayee.SelectedItem.Text, ddlPayee.SelectedItem.Value, txtRoomNoMobile.Text, t_Mobile, ddlDuesType.SelectedItem.Text, ddlDuesType.SelectedItem.Value, txtDuesAmount.Text, txtDuesDate.Text, txtDuesMonth.Text, txtRemark.Text);
                    string textmsg = " Dues Added Successfully";
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                    ddlPayee.SelectedIndex = 0;
                    txtRoomNoMobile.Text = string.Empty;
                    ddlDuesType.SelectedIndex = 0;
                    txtDuesAmount.Text = string.Empty;
                    txtDuesDate.Text = string.Empty;
                    txtDuesMonth.Text = string.Empty;
                    txtRemark.Text = string.Empty;
                    btnDues.Visible = true;
                    btnSaveChenges.Visible = false;
                }
                else
                {
                    string errormsg = "Please Select property name";
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + errormsg + "')</script>", false);
                }

            }
        }
        catch (Exception Ex)
        {
            string errormsg = Ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + errormsg + "')</script>", false);
        }
    }


    protected void ddlPayee_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPayee.SelectedItem.Value != "0")
        {

            SqlDataReader sdr = uc.GetNameroomNo(ddlPayee.SelectedItem.Value);
            if (sdr.HasRows)
            {
                if (sdr.Read())
                {
                    string RoomNo = sdr["t_RoomNo"].ToString();
                    string Mobile = sdr["t_MobileNo"].ToString();
                    Session["t_MobileNo"] = sdr["t_MobileNo"].ToString();
                    txtRoomNoMobile.Text = RoomNo + " (" + Mobile + ")";
                    Session["t_RoomNo"] = sdr["t_RoomNo"].ToString();
                }
            }
            sdr.Close();
        }
    }
    private void ddlProperty_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
        string PropertyName = ddlPropertyName.SelectedItem.Text;
        string PropertyVale = ddlPropertyName.SelectedValue;
        Gf.FillPayee("t_id", "t_name", "Tenants", ddlPayee, "", PropertyVale);
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        // Create an event handler for the master page's contentCallEvent event
        Master.contentCallEvent += new EventHandler(ddlProperty_SelectedIndexChanged);
    }
    protected void btnViewDues_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Content/Dues.aspx");
    }
    protected void btnSaveChenges_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlPayee.SelectedItem.Value != "0")
            {
                string d_id = Request.QueryString["d_id"].ToString();
                ed.UpdateDues(d_id, ddlPayee.SelectedItem.Text, ddlPayee.SelectedItem.Value, txtRoomNoMobile.Text, ddlDuesType.SelectedItem.Text, ddlDuesType.SelectedItem.Value, txtDuesAmount.Text, txtDuesDate.Text, txtDuesMonth.Text, txtRemark.Text);
                string textmsg = " Dues Added Successfully";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                ddlPayee.SelectedItem.Text = string.Empty;
                txtRoomNoMobile.Text = string.Empty;
                ddlDuesType.SelectedIndex = 0;
                txtDuesAmount.Text = string.Empty;
                txtDuesDate.Text = string.Empty;
                txtDuesMonth.Text = string.Empty;
                txtRemark.Text = string.Empty;
                btnDues.Visible = false;
                btnSaveChenges.Visible = true;
            }
            else
            {
                string errormsg = "Please Select property name";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + errormsg + "')</script>", false);
            }


        }
        catch (Exception Ex)
        {
            string errormsg = Ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + errormsg + "')</script>", false);
        }

    }
}