﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class content_ComplaintsMaster : System.Web.UI.Page
{
    GeneralFunctions.GeneralFunctions Gf = new GeneralFunctions.GeneralFunctions();
    AddUsers uc = new AddUsers();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["s_MobileNo"] != null)
            {
                loadfill();
            }
            else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                Response.Redirect("~/content/login.aspx");
            }
           
        }

    }

    protected void loadfill()
    {
        Gf.FillFaccingIssue("tc_id", "tc_name", "TicketCategory", ddlTicketCategory, "");
        Gf.FillFaccingIssue("tc_id", "tc_name", "TicketCategory", ddlTicketCategoryMainissue, "");

    }
    protected void loadTicketCategory()
    {
        Gf.FillFaccingIssue("tc_id", "tc_name", "TicketCategory", ddlTicketCategory, "");
        Gf.FillFaccingIssue("tc_id", "tc_name", "TicketCategory", ddlTicketCategoryMainissue, "");
    }
    protected void LoadFilter()
    {
        Gf.FillFaccingMainIssue("fi_id", "fi_name", "FacingIssue", ddlFacingIssue, "", ddlTicketCategoryMainissue.SelectedItem.Value);
    }
    protected void btnTicketCategory_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtTicketCategory.Text.Trim().Length > 0)
            {
                uc.AddTicketCategory(txtTicketCategory.Text);
                string textmsg = "Record Added Successfully !";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                txtTicketCategory.Text = string.Empty;
                loadTicketCategory();
            }
            else { }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }

    protected void btnbtnIssueCategory_Click(object sender, EventArgs e)
    {
        try
        {
            uc.AddIssueCategory(ddlTicketCategory.SelectedItem.Value, ddlTicketCategory.SelectedItem.Text, txtFacingIssueName.Text);
            string textmsg = "Record Added Successfully !";
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
            txtFacingIssueName.Text = string.Empty;
            LoadFilter();

        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void btnIssueSubCategory_Click(object sender, EventArgs e)
    {
        try
        {
            uc.AddIssueSubCategory(ddlTicketCategoryMainissue.SelectedItem.Value, ddlTicketCategoryMainissue.SelectedItem.Text, ddlFacingIssue.SelectedItem.Value, ddlFacingIssue.SelectedItem.Text, txtFacingIssueSubCategoryName.Text);
            string textmsg = "Record Added Successfully !";
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
            txtFacingIssueSubCategoryName.Text = string.Empty;
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void ddlTicketCategoryMainissue_SelectedIndexChanged(object sender, EventArgs e)
    {
        Gf.FillFaccingMainIssue("fi_id", "fi_name", "FacingIssue", ddlFacingIssue, "", ddlTicketCategoryMainissue.SelectedItem.Value);
    }
}