﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class content_kycDetails : System.Web.UI.Page
{
    AddUsers uc = new AddUsers();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["s_MobileNo"] != null)
            {
                if (Session["propertyvalue"] != null)
                {
                    if (Session["propertyvalue"].ToString() == "0")
                    {
                        // Session.Remove("propertyvalue");
                        showKYCofTenants();
                    }
                    else
                    {
                        showKYCofTenants();
                    }
                }
                else
                {
                    Session["propertyvalue"] = "0";
                    showKYCofTenants();
                }

            }
            else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                Response.Redirect("~/content/login.aspx");
            }

        }
    }

    private void showKYCofTenants()
    {
        try
        {
            //if (Session["propertyvalue"] != null)
            //{
               // string propertyvalue = Session["propertyvalue"].ToString();
                GridView1.DataSource = uc.LoadKycOfTenants();
                GridView1.DataBind();
           // }
            //else
            //{
            //    Session.Remove("propertyvalue");
            //    Session["propertyvalue"] = "0";
            //    showKYCofTenants();
            //}
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {
        try
        {
            GridView1.DataSource = uc.LoadKycOfTenantsbySearch(txtSearch.Text);
            GridView1.DataBind();
            
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void lbtSearchKYC_Click(object sender, EventArgs e)
    {
        try
        {
            GridView1.DataSource = uc.LoadKycOfTenantsbySearch(txtSearch.Text);
            GridView1.DataBind();

        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
   
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        try
        {

            if (e.CommandName == "DownloadFront")
            {
                string k_id = e.CommandArgument.ToString();
                SqlDataReader sdr = uc.GetFileFront(k_id);

                if (sdr.HasRows)
                {
                    sdr.Read();
                    string file = sdr["k_frontPath"].ToString();
                    Response.Redirect("http://www.stayello.com/" + file + "");
                }
                else
                {
                    string text = "File Not Uploded";
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
                }
            }
            else if (e.CommandName == "DownloadBack")
            {
                string k_id = e.CommandArgument.ToString();
                SqlDataReader sdr = uc.GetFileFront(k_id);

                if (sdr.HasRows)
                {
                    sdr.Read();
                    string file = sdr["k_BackPath"].ToString();
                    Response.Redirect("http://www.stayello.com/" + file + "");
                }
                else
                {
                    string text = "File Not Uploded";
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
                }
            }


        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
}