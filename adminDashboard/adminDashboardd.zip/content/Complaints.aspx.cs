﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class content_Complaints : System.Web.UI.Page
{
    GeneralFunctions.GeneralFunctions Gf = new GeneralFunctions.GeneralFunctions();
    AddUsers uc = new AddUsers();
    MasterData md = new MasterData();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["s_MobileNo"] != null)
            {
                if (Session["propertyvalue"] != null)
                {
                    if (Session["propertyvalue"].ToString() == "0")
                    {
                        // Session.Remove("propertyvalue");
                        ShowNewcomplaints();
                        ShowOngoingcomplaints();
                        ShowResolvedcomplaints();
                    }
                    else
                    {
                        ShowNewcomplaints();
                        ShowOngoingcomplaints();
                        ShowResolvedcomplaints();
                    }
                }
                else
                {
                    Session["propertyvalue"] = "0";
                    ShowNewcomplaints();
                    ShowOngoingcomplaints();
                    ShowResolvedcomplaints();
                }

            }
            else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                Response.Redirect("~/content/login.aspx");

            }

        }

    }

    private void ShowResolvedcomplaints()
    {
        try
        {
            if (Session["propertyvalue"] != null)
            {
                string tc_PropertyVal = Session["propertyvalue"].ToString();
                ListView3.DataSource = uc.GetResolvedComplaints(tc_PropertyVal);
                ListView3.DataBind();
            }
            else
            {
                Session["propertyvalue"] = "0";
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }

    private void ddlProperty_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
            string PropertyName = ddlPropertyName.SelectedItem.Text;
            string PropertyVale = ddlPropertyName.SelectedItem.Value;
            ShowNewcomplaints();
            ShowOngoingcomplaints();
            ShowResolvedcomplaints();

        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        // Create an event handler for the master page's contentCallEvent event
        Master.contentCallEvent += new EventHandler(ddlProperty_SelectedIndexChanged);
    }

    private void ShowOngoingcomplaints()
    {
        try
        {
            if (Session["propertyvalue"] != null)
            {
                string tc_PropertyVal = Session["propertyvalue"].ToString();
                ListView2.DataSource = uc.GetOngoingComplaints(tc_PropertyVal);
                ListView2.DataBind();
            }
            else
            {
                Session["propertyvalue"] = "0";
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }

    private void ShowNewcomplaints()
    {
        try
        {
            if (Session["propertyvalue"] != null)
            {
                string tc_PropertyVal = Session["propertyvalue"].ToString();
                ListView1.DataSource = uc.GetNewComplaints(tc_PropertyVal);
                ListView1.DataBind();
            }
            else
            {
                Session["propertyvalue"] = "0";
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }

    }
    protected void btnAddNewComplaints_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/content/ComplaintsMaster.aspx");
    }

    protected void ListView1_ItemDataBound(object sender, ListViewItemEventArgs e)
    {

        try
        {
            DropDownList ddlcomplaints = (e.Item.FindControl("ddlcomplaints") as DropDownList);
            ddlcomplaints.DataSource = md.GetCompLaints(); ;
            ddlcomplaints.DataTextField = "cp_name";
            ddlcomplaints.DataValueField = "cp_id";
            ddlcomplaints.DataBind();
            ddlcomplaints.Items.Insert(0, new ListItem { Text = "--Select--", Value = "0" });
            Label lbltc_id = (e.Item.FindControl("lbltc_id") as Label);
            SqlDataReader sdr = uc.getStatus(lbltc_id.Text);
            if (sdr.HasRows)
            {
                if (sdr.Read())
                {
                    DropDownList ddlcomplaint = (e.Item.FindControl("ddlcomplaints") as DropDownList);
                    ddlcomplaint.SelectedItem.Text = sdr["tc_status"].ToString();
                }
            }
            sdr.Close();
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void ListView2_ItemDataBound(object sender, ListViewItemEventArgs e)
    {
        try
        {
            DropDownList ddlcomplaints = (e.Item.FindControl("ddlcomplaints") as DropDownList);
            ddlcomplaints.DataSource = md.GetCompLaints();
            ddlcomplaints.DataTextField = "cp_name";
            ddlcomplaints.DataValueField = "cp_id";
            ddlcomplaints.DataBind();
            ddlcomplaints.Items.Insert(0, new ListItem { Text = "--Select--", Value = "0" });

            Label lbltc_id = (e.Item.FindControl("lbltc_id") as Label);
            SqlDataReader sdr = uc.getStatus(lbltc_id.Text);
            if (sdr.HasRows)
            {
                if (sdr.Read())
                {
                    DropDownList ddlcomplaint = (e.Item.FindControl("ddlcomplaints") as DropDownList);
                    ddlcomplaint.SelectedItem.Text = sdr["tc_status"].ToString();
                }
            }
            sdr.Close();
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }

    protected void ddlcomplaints_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DropDownList ddlListFind = (DropDownList)sender;
            ListViewItem item1 = (ListViewItem)ddlListFind.NamingContainer;
            DropDownList ddlcomplaints = (DropDownList)item1.FindControl("ddlcomplaints");

            Label tc_id = (Label)item1.FindControl("lbltc_id");
            uc.UpdateStatusComplaints(tc_id.Text, ddlcomplaints.SelectedItem.Text);
            ShowNewcomplaints();
            ShowOngoingcomplaints();
            ShowResolvedcomplaints();
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void ddlcomplaints_SelectedIndexChanged1(object sender, EventArgs e)
    {
        try
        {
            DropDownList ddlListFind = (DropDownList)sender;
            ListViewItem item1 = (ListViewItem)ddlListFind.NamingContainer;
            DropDownList ddlcomplaints = (DropDownList)item1.FindControl("ddlcomplaints");
            Label tc_id = (Label)item1.FindControl("lbltc_id");
            uc.UpdateStatusComplaints(tc_id.Text, ddlcomplaints.SelectedItem.Text);
            ShowNewcomplaints();
            ShowOngoingcomplaints();
            ShowResolvedcomplaints();
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void lbtSearchComplaints_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["propertyvalue"] != null)
            {
                string tc_PropertyVal = Session["propertyvalue"].ToString();
                ListView1.DataSource = uc.GetNewComplaintsbySearch(tc_PropertyVal, txtSearch.Text);
                ListView1.DataBind();
                ListView2.DataSource = uc.GetOngoingComplaintsbySearch(tc_PropertyVal, txtSearch.Text);
                ListView2.DataBind();
                ListView3.DataSource = uc.GetResolvedComplaintsbySearch(tc_PropertyVal, txtSearch.Text);
                ListView3.DataBind();
            }
            else
            {
                Session["propertyvalue"] = "0";
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (Session["propertyvalue"] != null)
            {
                string tc_PropertyVal = Session["propertyvalue"].ToString();
                ListView1.DataSource = uc.GetNewComplaintsbySearch(tc_PropertyVal, txtSearch.Text);
                ListView1.DataBind();
                ListView2.DataSource = uc.GetOngoingComplaintsbySearch(tc_PropertyVal, txtSearch.Text);
                ListView2.DataBind();
                ListView3.DataSource = uc.GetResolvedComplaintsbySearch(tc_PropertyVal, txtSearch.Text);
                ListView3.DataBind();
            }
            else
            {
                Session["propertyvalue"] = "0";
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
}