﻿using ConnectionString;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class content_AddTenants : System.Web.UI.Page
{
    GeneralFunctions.GeneralFunctions Gf = new GeneralFunctions.GeneralFunctions();
    AddUsers uc = new AddUsers();
    EditData ed = new EditData();
    protected void Page_Load(object sender, EventArgs e)
    {
       // DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
        //string PropertyVale = ddlPropertyName.SelectedValue;

        if (!IsPostBack)
        {
            if (Session["s_MobileNo"] != null)
            {
                if (Session["propertyvalue"] != null)
                {
                    string PropertyVale = Session["propertyvalue"].ToString();
                    Gf.FillRooms("r_id", "r_roomNo", "Rooms", ddlRoomNo, "", PropertyVale);

                    if (Session["propertyvalue"].ToString() == "0")
                    {
                        Session["propertyvalue"] = "1";
                    }
                    else
                    {
                    }
                }
                else
                {
                    Session["propertyvalue"] = "1";
                }



                btnTenants.Visible = true;
                btnSaveChenges.Visible = false;


                if (Request.QueryString["t_id"] != null)
                {
                    string t_id = Request.QueryString["t_id"].ToString();
                    Session["t_id"] = Request.QueryString["t_id"].ToString();
                    LoadTenants(t_id);
                    btnTenants.Visible = false;
                    btnSaveChenges.Visible = true;
                }
            }
            else
            {
                Session.Abandon();
                Session.Clear();
                Session.RemoveAll();
                Response.Redirect("~/content/login.aspx");
            }
        }

    }

    private void LoadTenants(string t_id)
    {

        SqlDataReader sdr = ed.GetTenants(t_id);
        if (sdr.HasRows)
        {
            if (sdr.Read())
            {
                txtName.Text = sdr["t_Name"].ToString();
                txtMobileNo.Text = sdr["t_MobileNo"].ToString();
                ddlRoomNo.SelectedItem.Text = sdr["t_RoomNo"].ToString();
                txtRoomType.Text = sdr["t_BedsText"].ToString();
                txtSecurityMoney.Text = sdr["t_SecurityMoney"].ToString();
                txtRentMoney.Text = sdr["t_RentMoney"].ToString();
                txtDateOfJoining.Text = sdr["t_DateOfJoining"].ToString();
                txtRentDate.Text = sdr["t_RentDate"].ToString();
                txtDetails.Text = sdr["t_Details"].ToString();
                Session["t_BedsValue"] = sdr["t_BedsValue"].ToString();
                btnTenants.Visible = false;
                btnSaveChenges.Visible = true;
            }
        }
        sdr.Close();
    }
    protected void btnTenants_Click(object sender, EventArgs e)
    {
        try
        {
            if (ddlRoomNo.SelectedIndex != 0)
            {
                if ((checkDublicateRoomNO() == false) && (checkRoomOccupency() == true))
                {
                    string mobile = Session["s_MobileNo"].ToString();
                    DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
                    string PropertyName = ddlPropertyName.SelectedItem.Text;
                    string PropertyVale = ddlPropertyName.SelectedValue;
                    string bedValue = Session["r_BedsValue"].ToString();
                    uc.AddTenants(mobile, PropertyName, PropertyVale, txtName.Text, txtMobileNo.Text, ddlRoomNo.SelectedItem.Text, txtRoomType.Text, bedValue, txtSecurityMoney.Text, txtRentMoney.Text, txtDateOfJoining.Text, txtRentDate.Text, txtDetails.Text);
                    string textmsg = "Tenants " + txtName.Text + " Room " + ddlRoomNo.SelectedItem.Text + " Aloted Successfully !";
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                    txtName.Text = string.Empty;
                    txtMobileNo.Text = string.Empty;
                    txtSecurityMoney.Text = string.Empty;
                    txtRentMoney.Text = string.Empty;
                    txtDateOfJoining.Text = string.Empty;
                    txtRentDate.Text = string.Empty;
                    txtDetails.Text = string.Empty;
                }
            }
            else
            {
                string text = "Room Not selected Or not Found";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }

    private bool checkDublicateRoomNO()
    {
        bool result = false;

        SqlDataReader sdr = uc.CheckDublicateTenent(txtMobileNo.Text);
        if (sdr.HasRows)
        {
            sdr.Read();
            string roomNo = sdr["t_RoomNo"].ToString();
            string t_name = sdr["t_name"].ToString();
            string t_MobileNo = sdr["t_MobileNo"].ToString();
            result = true;
            string text = "This Tenants  " + t_name + "  and  " + t_MobileNo + " Already Aloted Room No " + roomNo + " ";
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
        sdr.Close();
        return result;
    }

    private bool checkRoomOccupency()
    {
        bool result = false;
        DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
        string PropertyName = ddlPropertyName.SelectedItem.Text;
        string PropertyVale = ddlPropertyName.SelectedValue;
        SqlDataReader sdr2 = uc.CheckOccupency1(PropertyVale, ddlRoomNo.SelectedItem.Text);

        if (sdr2.HasRows)
        {
            sdr2.Read();
            Session["r_BedsValue"] = Convert.ToInt32(sdr2["r_BedsValue"]);
        }
        sdr2.Close();
        SqlDataReader sdr = uc.CheckOccupency(PropertyVale, ddlRoomNo.SelectedItem.Text);

        if (sdr.HasRows)
        {
            sdr.Read();

            Int32 tenantsCount = Convert.ToInt32(sdr["countTen"]);
            int r_BedsValue = Convert.ToInt32(Session["r_BedsValue"]);
            Session["r_BedsValue"] = r_BedsValue.ToString();
            if (r_BedsValue > tenantsCount)
            {
                result = true;
            }

            else
            {
                result = false;
                string text = "This  " + ddlRoomNo.SelectedItem.Text + "  olny   " + r_BedsValue + " capacity  so sorry this room already full ";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
            }
            sdr.Close();
        }
        else
        {
            result = true;
        }
        return result;
    }


    private void ddlProperty_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
        string PropertyVale = ddlPropertyName.SelectedValue;
        Gf.FillRooms("r_id", "r_roomNo", "Rooms", ddlRoomNo, "", PropertyVale);
        // This Method will be Called.
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        // Create an event handler for the master page's contentCallEvent event
        Master.contentCallEvent += new EventHandler(ddlProperty_SelectedIndexChanged);
    }
    protected void btnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/content/Tenants.aspx");
    }
    protected void txtMobileNo_TextChanged(object sender, EventArgs e)
    {
        SqlDataReader sdr = ed.CheckTenantsExist(txtMobileNo.Text);

        if (sdr.HasRows)
        {
            sdr.Read();
            string roomNo = sdr["t_RoomNo"].ToString();
            string t_name = sdr["t_name"].ToString();
            string t_MobileNo = sdr["t_MobileNo"].ToString();
            string text = "This Tenants  " + t_name + "  and  " + t_MobileNo + " Already Aloted Room No " + roomNo + " ";
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
        sdr.Close();
    }
    protected void ddlRoomNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlRoomNo.SelectedItem.Value != "0")
            {
                DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
                string PropertyName = ddlPropertyName.SelectedItem.Text;
                string PropertyVale = ddlPropertyName.SelectedValue;
                SqlDataReader sdr = uc.GetBedType(PropertyVale, ddlRoomNo.SelectedItem.Text);
                if (sdr.HasRows)
                {
                    if (sdr.Read())
                    {
                        txtRoomType.Text = sdr["r_BedsText"].ToString();
                        Session["bedValue"] = sdr["r_BedsValue"].ToString();
                    }
                }
                sdr.Close();
            }
        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
    protected void btnSaveChenges_Click(object sender, EventArgs e)
    {
        try
        {
            
                DropDownList ddlPropertyName = (DropDownList)Master.FindControl("ddlProperty");
                string PropertyName = ddlPropertyName.SelectedItem.Text;
                string PropertyVale = ddlPropertyName.SelectedValue;
                SqlDataReader sdr = uc.GetBedType(PropertyVale, ddlRoomNo.SelectedItem.Text);
                if (sdr.HasRows)
                {
                    if (sdr.Read())
                    {
                        txtRoomType.Text = sdr["r_BedsText"].ToString();
                        Session["bedValue"] = sdr["r_BedsValue"].ToString();
                    }
                }
                sdr.Close();
            
            string t_id = Session["t_id"].ToString();

            string bedvalue = Session["bedValue"].ToString();
            if (bedvalue != null)
            {
                string bedValue = Session["bedValue"].ToString();
                ed.UpdateTenants(t_id, txtName.Text, txtMobileNo.Text, ddlRoomNo.SelectedItem.Text, txtRoomType.Text, ddlRoomNo.SelectedItem.Value, txtSecurityMoney.Text, txtRentMoney.Text, txtDateOfJoining.Text, txtRentDate.Text, txtDetails.Text);
                string textmsg = "Tenants " + txtName.Text + " Room " + ddlRoomNo.SelectedItem.Text + " Updated Successfully !";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                txtName.Text = string.Empty;
                txtMobileNo.Text = string.Empty;
                txtSecurityMoney.Text = string.Empty;
                txtRentMoney.Text = string.Empty;
                txtDateOfJoining.Text = string.Empty;
                txtRentDate.Text = string.Empty;
                txtDetails.Text = string.Empty;
            }
            else
            {
                string bedValue = Session["t_BedsValue"].ToString();
                ed.UpdateTenants(t_id, txtName.Text, txtMobileNo.Text, ddlRoomNo.SelectedItem.Text, txtRoomType.Text, bedValue, txtSecurityMoney.Text, txtRentMoney.Text, txtDateOfJoining.Text, txtRentDate.Text, txtDetails.Text);
                string textmsg = "Tenants " + txtName.Text + " Room " + ddlRoomNo.SelectedItem.Text + " Updated Successfully !";
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpopsuccess('" + textmsg + "')</script>", false);
                txtName.Text = string.Empty;
                txtMobileNo.Text = string.Empty;
                txtSecurityMoney.Text = string.Empty;
                txtRentMoney.Text = string.Empty;
                txtDateOfJoining.Text = string.Empty;
                txtRentDate.Text = string.Empty;
                txtDetails.Text = string.Empty;
            }


        }
        catch (Exception ex)
        {
            string text = ex.Message.ToString();
            ScriptManager.RegisterStartupScript(this, typeof(Page), "Warning", "<script>showpoperror('" + text + "')</script>", false);
        }
    }
}